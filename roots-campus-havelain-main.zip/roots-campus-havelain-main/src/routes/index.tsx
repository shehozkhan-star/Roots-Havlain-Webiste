import { createFileRoute } from "@tanstack/react-router";
import logoJson from "@/assets/roots-logo.png.asset.json";
import posterJson from "@/assets/poster.jpg.asset.json";
import kidsJson from "@/assets/kids.jpg.asset.json";
import v1Json from "@/assets/v1.mp4.asset.json";
import v2Json from "@/assets/v2.mp4.asset.json";
import v3Json from "@/assets/v3.mp4.asset.json";
import v4Json from "@/assets/v4.mp4.asset.json";
import exploreJson from "@/assets/exploreville.png.asset.json";
import miucJson from "@/assets/miuc.jpg.asset.json";
import mscJson from "@/assets/msc.png.asset.json";

type Asset = { url: string };
const logo = (logoJson as Asset).url;
const poster = (posterJson as Asset).url;
const kids = (kidsJson as Asset).url;
const explore = (exploreJson as Asset).url;
const miuc = (miucJson as Asset).url;
const msc = (mscJson as Asset).url;
const videos = [
  (v1Json as Asset).url,
  (v2Json as Asset).url,
  (v3Json as Asset).url,
  (v4Json as Asset).url,
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Roots International Schools – Havelian Campus, Irshad Nagar" },
      { name: "description", content: "Admissions open for Playgroup Early Start Program at Roots International Schools, Havelian Campus, Irshad Nagar. Activity-based learning, caring teachers, safe environment." },
      { property: "og:title", content: "Roots International Schools – Havelian Campus" },
      { property: "og:description", content: "Playgroup Early Start Program – Admissions Open. Starting 1st August." },
      { property: "og:image", content: poster },
    ],
  }),
  component: Home,
});

const features = [
  { icon: "🧩", title: "Activity-Based Learning", desc: "Hands-on play that sparks curiosity." },
  { icon: "🔤", title: "Phonics & Early Literacy", desc: "Strong foundations in sounds and reading." },
  { icon: "📖", title: "Rhymes & Storytelling", desc: "Imagination through songs and stories." },
  { icon: "🤝", title: "Social Skills & Confidence", desc: "Learning to share, lead, and belong." },
  { icon: "✋", title: "Motor Skills & Creative Play", desc: "Building dexterity through art and play." },
  { icon: "🔢", title: "Numbers, Colours & Shapes", desc: "First steps in numeracy and observation." },
  { icon: "🛡️", title: "Safe & Nurturing", desc: "A protected space to grow with confidence." },
  { icon: "👩‍🏫", title: "Caring Teachers", desc: "Experienced educators who truly listen." },
];

function Home() {
  return (
    <div className="min-h-screen bg-[#fffaf0] text-slate-800">
      {/* Top bar */}
      <div className="bg-[#5a0a12] text-white text-xs">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-2">
          <span className="hidden sm:inline">📍 Havelian Campus · Irshad Nagar</span>
          <span className="font-medium">Admissions Open for Playgroup · Starting 1st August</span>
          <a href="tel:+923459414000" className="hidden sm:inline hover:text-yellow-300">📞 0345-9414000</a>
        </div>
      </div>

      {/* Header */}
      <header className="bg-gradient-to-r from-[#7a0d18] via-[#7a0d18] to-[#5a0a12] text-white shadow-lg">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-5">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Roots International Schools" className="h-14 w-14 rounded-lg bg-white p-1 shadow" />
            <div>
              <h1 className="text-base font-bold leading-tight sm:text-xl">Roots International Schools</h1>
              <p className="text-[11px] opacity-90 sm:text-sm">Havelian Campus · Irshad Nagar</p>
            </div>
          </div>
          <img
            src={explore}
            alt="Exploreville Schools & Colleges"
            className="h-12 rounded-md bg-white px-3 py-1 shadow sm:h-14"
          />
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-[#fff7e6]">
        <img src={poster} alt="Playgroup Early Start Program – Admissions Open" className="mx-auto w-full max-w-7xl" />
      </section>

      {/* Intro */}
      <section className="mx-auto max-w-5xl px-4 py-14 text-center">
        <span className="inline-block rounded-full bg-red-600 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-white shadow-md">
          Admissions Open
        </span>
        <h2 className="mt-5 text-4xl font-extrabold tracking-tight text-[#7a0d18] sm:text-5xl">
          Playgroup Early Start Program
        </h2>
        <p className="mt-3 text-lg font-semibold text-indigo-700">Starting from 1st August</p>
        <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-slate-700 sm:text-lg">
          A special program for young children who are now ready to begin school. From{" "}
          <span className="font-bold text-red-600">August to February</span>, we help children learn, grow and prepare confidently for the next academic session.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <a href="tel:+923459414000" className="rounded-full bg-[#7a0d18] px-7 py-3 text-sm font-bold text-white shadow-lg transition hover:bg-[#5a0a12]">
            📞 Call to Enroll
          </a>
          <a href="https://wa.me/923459414000" target="_blank" rel="noopener noreferrer" className="rounded-full bg-green-500 px-7 py-3 text-sm font-bold text-white shadow-lg transition hover:bg-green-600">
            💬 WhatsApp Now
          </a>
        </div>
      </section>

      {/* Features */}
      <section className="bg-white py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="text-center">
            <p className="text-xs font-bold uppercase tracking-widest text-yellow-600">Why Parents Choose Us</p>
            <h3 className="mt-2 text-3xl font-bold text-[#7a0d18] sm:text-4xl">What Your Child Will Experience</h3>
          </div>
          <div className="mt-10 grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
            {features.map((f) => (
              <div
                key={f.title}
                className="group rounded-2xl border border-yellow-200 bg-gradient-to-br from-yellow-50 to-white p-6 text-center shadow-sm transition-all hover:-translate-y-1 hover:border-[#7a0d18]/30 hover:shadow-xl"
              >
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#7a0d18]/10 text-3xl transition group-hover:bg-[#7a0d18]/20">
                  {f.icon}
                </div>
                <h4 className="mt-3 text-sm font-bold text-[#7a0d18]">{f.title}</h4>
                <p className="mt-1 text-xs text-slate-600">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Photo */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div className="relative">
            <div className="absolute -inset-3 rounded-3xl bg-gradient-to-br from-yellow-300 to-[#7a0d18] opacity-20 blur-2xl" />
            <img
              src={kids}
              alt="Children learning together at Roots International"
              className="relative rounded-3xl shadow-2xl"
            />
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-yellow-600">A Confident Start</p>
            <h3 className="mt-2 text-3xl font-extrabold text-[#7a0d18] sm:text-4xl">
              Give Your Child a Confident Start
            </h3>
            <p className="mt-4 text-slate-700">
              Small class sizes, playful and safe learning spaces, and experienced teachers who nurture every child's curiosity and confidence.
            </p>
            <ul className="mt-5 space-y-3 text-slate-700">
              {[
                "Experienced & Caring Teachers",
                "Small Class Size",
                "Playful & Safe Environment",
                "Roots International Quality Education",
              ].map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-6 w-6 flex-none items-center justify-center rounded-full bg-green-500 text-xs font-bold text-white">
                    ✓
                  </span>
                  <span className="font-medium">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Videos */}
      <section className="bg-gradient-to-b from-slate-50 to-slate-100 py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="text-center">
            <p className="text-xs font-bold uppercase tracking-widest text-yellow-600">Campus Life</p>
            <h3 className="mt-2 text-3xl font-bold text-[#7a0d18] sm:text-4xl">A Peek Into Our Campus</h3>
            <p className="mt-2 text-slate-600">Watch our little learners in action.</p>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-2">
            {videos.map((src) => (
              <video
                key={src}
                src={src}
                controls
                playsInline
                preload="metadata"
                className="w-full rounded-2xl bg-black shadow-xl ring-1 ring-black/10"
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#7a0d18] via-[#7a0d18] to-[#3a0509] py-16 text-white">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 20% 20%, #facc15 0, transparent 40%), radial-gradient(circle at 80% 80%, #ef4444 0, transparent 40%)" }} />
        <div className="relative mx-auto max-w-4xl px-4 text-center">
          <h3 className="text-3xl font-extrabold sm:text-4xl">Book a Free School Visit Today!</h3>
          <p className="mt-3 text-white/90">Missed March admission? Your child can still start strong from August.</p>
          <div className="mt-7 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <a href="tel:+923459414000" className="rounded-full bg-yellow-400 px-8 py-3.5 text-lg font-bold text-slate-900 shadow-lg transition hover:scale-105 hover:bg-yellow-300">
              📞 0345-9414000
            </a>
            <a href="https://wa.me/923459414000" target="_blank" rel="noopener noreferrer" className="rounded-full bg-green-500 px-8 py-3.5 text-lg font-bold text-white shadow-lg transition hover:scale-105 hover:bg-green-400">
              💬 WhatsApp Us
            </a>
          </div>
          <p className="mt-6 text-sm text-white/80">📍 Havelian Campus, Irshad Nagar</p>
        </div>
      </section>

      {/* Affiliations */}
      <section className="border-t-4 border-yellow-400 bg-white py-12">
        <div className="mx-auto max-w-6xl px-4 text-center">
          <p className="text-xs font-bold uppercase tracking-widest text-slate-500">Proudly Affiliated With</p>
          <h4 className="mt-1 text-xl font-bold text-[#7a0d18] sm:text-2xl">Part of a Trusted Education Network</h4>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-10 sm:gap-16">
            <img src={miuc} alt="Metropolitan International United College (MIUC)" className="h-16 object-contain sm:h-20" />
            <img src={msc} alt="Metropolitan Schools & Colleges" className="h-16 object-contain sm:h-20" />
          </div>
        </div>
      </section>

      <footer className="bg-slate-900 py-8 text-center text-sm text-slate-400">
        <p>© {new Date().getFullYear()} Roots International Schools – Havelian Campus. All rights reserved.</p>
        <p className="mt-1 text-xs">Irshad Nagar, Havelian · 0345-9414000</p>
      </footer>
    </div>
  );
}
